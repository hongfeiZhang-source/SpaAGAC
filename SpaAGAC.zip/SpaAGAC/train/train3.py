import torch
from torch.optim import Adam
import torch.nn.functional as F
from sklearn.cluster import KMeans
import numpy as np  
import pandas as pd  
from sklearn.cluster import KMeans  
import community as louvain  
from scipy.cluster.hierarchy import linkage, fcluster  
from sklearn.metrics import pairwise_distances   
from utils.misc import *
import os
import numpy as np
import random
from train.utils import clustering
import numpy as np
import pandas as pd
from scipy.spatial.distance import squareform
from scipy.cluster import hierarchy 
from train.utils import search_res_for_ensemble
# Calculate InfoNCE-like loss. Considering spatial neighbors as positive pairs for each spot
def Noise_Cross_Entropy(emb, adj):
    sim = cosine_sim_tensor(emb)
    sim_exp = torch.exp(sim)

    # negative pairs
    n = torch.mul(sim_exp, 1 - adj).sum(axis=1)
    # positive pairs
    p = torch.mul(sim_exp, adj).sum(axis=1)

    ave = torch.div(p, n)
    loss = -torch.log(ave).mean()

    return loss

# Calculate cosine similarity.
def cosine_sim_tensor(emb):
    M = torch.matmul(emb, emb.T)
    length = torch.norm(emb, p=2, dim=1)
    Norm = torch.matmul(length.reshape((emb.shape[0], 1)), length.reshape((emb.shape[0], 1)).T) + -5e-12      # reshape((emb.shape[0], 1))
    M = torch.div(M, Norm)
    if torch.any(torch.isnan(M)):
        M = torch.where(torch.isnan(M), torch.full_like(M, 0.4868), M)

    return M
BCE_loss = torch.nn.BCEWithLogitsLoss()
KL_loss = torch.nn.KLDivLoss(reduction='batchmean')

def Train(epochs, model,adata, data,data1, adj, label, device,args):
    acc_reuslt = []
    nmi_result = []
    ari_result = []
    ami_result = []
    optimizer = Adam(model.parameters(), lr=args.lr)
    # model.load_state_dict(torch.load(f'save/{args.dataset}/pretrain.pkl', map_location='cpu'))
    # with torch.no_grad():
    #     fea = model.init(data,data1, adj)
    # kmeans = KMeans(n_clusters=args.n_clusters, n_init=20)
    # cluster_id = kmeans.fit_predict(fea.data.cpu().numpy())
    # model.cluster_layer.data = torch.tensor(kmeans.cluster_centers_).to(device)
    ari=0
    for epoch in range(epochs):
        x_hat, z_ae, z_igae,x_hat1, z_ae1, z_igae1,  fea,total_loss = model(data,data1, adj)

        # tmp_q = q.data
        # p = target_distribution(tmp_q).detach()

        adj_ = torch.mm(fea, fea.T)
        if adj_.is_sparse:  
                adj_ = adj_.to_dense()  
        adj_spatial=adj
        if adj_spatial.is_sparse:  
            adj_spatial = adj_spatial.to_dense()  
        loss_adj_1 = BCE_loss(adj_, adj_spatial)

        loss = total_loss+ args.loss_s * loss_adj_1


        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if epoch % 10 == 9:
            with torch.no_grad():
                x_hat, z_ae, z_igae,x_hat1, z_ae1, z_igae1,  fea,total_loss= model(data,data1, adj)
                print('{:3d} loss: {}'.format(epoch, loss))
                # kmeans = KMeans(n_clusters=args.n_clusters1, n_init=10).fit(fea.data.cpu().numpy())
                adata.obsm['SpaAGAC']=fea.data.cpu().numpy()
                if args.tool=='mclust':
                    clustering(adata, key='SpaAGAC', add_key='SpaAGAC', n_clusters=args.n_clusters, method=args.tool, use_pca=True)
                elif args.tool=='kmeans': 
                    kmeans = KMeans(n_clusters=args.n_clusters, n_init=10).fit(fea.data.cpu().numpy())  
                    adata.obs['SpaAGAC']=kmeans.labels_
                elif args.tool == 'leiden': # mclust, leiden, and louvain
                    clustering(adata, key='SpaAGAC', add_key='SpaAGAC', n_clusters=args.n_clusters, method=args.tool, use_pca=True)
                nmi, ari, ami, homogeneity, completeness, v_measure = eva(label, adata.obs['SpaAGAC'], epoch)
                nmi_result.append(nmi)
                ari_result.append(ari)
                ami_result.append(ami)
    print_results( nmi_result, ari_result, ami_result, args,'xunlian')
    return model


def consensus_clustering(cluster_assignments, n_clusters):
    """
    Perform consensus clustering from multiple clusterings
    
    Parameters:
        cluster_assignments: list of array-like
            List of cluster assignments from different resolutions
        n_clusters: int
            Desired number of final clusters
    """

    cluster_assignments = [np.asarray(labels).flatten() for labels in cluster_assignments]
    n_cells = len(cluster_assignments[0])
    
    
    for labels in cluster_assignments:
        if len(labels) != n_cells:
            raise ValueError("All cluster assignments must have the same length")
    
    # Create co-association matrix
    coassociation = np.zeros((n_cells, n_cells))
    
    for labels in cluster_assignments:

        labels = labels.astype(int)

        connectivity = (labels[:, None] == labels[None, :]).astype(int)
        coassociation += connectivity
    
    # Normalize by number of clusterings
    coassociation /= len(cluster_assignments)
    
    # Apply hierarchical clustering
    distances = 1 - coassociation
    linkage = hierarchy.linkage(squareform(distances), method='average')
    consensus_labels = hierarchy.cut_tree(linkage, n_clusters=n_clusters).flatten()
    
    return consensus_labels
def Test(model,adata, data,data1, adj, label, device, args,tool='kmeans'):
    acc_reuslt = []
    nmi_result = []
    ari_result = []
    ami_result = []
    homogeneity_result = []
    completeness_result = []
    v_measure_result = []
    torch.manual_seed(args.random_seed)
    random.seed(args.random_seed)
    np.random.seed(args.random_seed)
    with torch.no_grad():
        x_hat, z_ae, z_igae,x_hat1, z_ae1, z_igae1,  fea,total_loss= model(data,data1, adj)
    
        if tool=='kmeans':
            # from sklearn.decomposition import PCA  
            # from sklearn.cluster import KMeans  


            kmeans = KMeans(n_clusters=args.n_clusters, n_init=10).fit(fea.data.cpu().numpy())  
            pred = kmeans.labels_  
            # kmeans = KMeans(n_clusters=args.n_clusters, n_init=10).fit(fea.data.cpu().numpy())
            # pred=kmeans.labels_
        elif tool=='Spectral':
            from sklearn.cluster import SpectralClustering
            spectral = SpectralClustering(n_clusters=args.n_clusters)
            pred = spectral.fit_predict(fea.data.cpu().numpy())
        elif tool == 'mclust': # mclust, leiden, and louvain
            adata.obsm['SpaAGAC']=fea.data.cpu().numpy()
            clustering(adata, key='SpaAGAC', add_key='SpaAGAC', n_clusters=args.n_clusters, method=tool, use_pca=True)
            pred=adata.obs['mclust']
        elif tool == 'leiden': # mclust, leiden, and louvain
            adata.obsm['SpaAGAC']=fea.data.cpu().numpy()
            clustering(adata, key='SpaAGAC', add_key='SpaAGAC', n_clusters=args.n_clusters, method=tool, use_pca=True)
            pred=adata.obs['leiden']
        elif tool == 'louvain': # mclust, leiden, and louvain
            adata.obsm['SpaAGAC']=fea.data.cpu().numpy()
            clustering(adata, key='SpaAGAC', add_key='SpaAGAC', n_clusters=args.n_clusters, method=tool, use_pca=True)
            pred=adata.obs['leiden']
        elif tool =='kmeans_jc':
            from scipy.optimize import linear_sum_assignment

  
            features = fea.data.cpu().numpy()

   
            n_runs = 50
            n_clusters = args.n_clusters

            all_labels = []

            for seed in range(10,n_runs+10):
                kmeans = KMeans(n_clusters=n_clusters, n_init=seed, random_state=42).fit(features)
                labels = kmeans.labels_
                all_labels.append(labels)

            all_labels = np.array(all_labels)  # shape: (n_runs, n_samples)

            reference_labels = all_labels[0]


            aligned_labels = np.zeros_like(all_labels)

            aligned_labels[0] = reference_labels

            for i in range(1, n_runs):

                contingency = np.zeros((n_clusters, n_clusters), dtype=int)
                for r in range(n_clusters):
                    for c in range(n_clusters):
                        contingency[r, c] = np.sum((reference_labels == r) & (all_labels[i] == c))
              
                row_ind, col_ind = linear_sum_assignment(-contingency)
             
                label_map = {c: r for r, c in zip(row_ind, col_ind)}
             
                aligned_labels[i] = [label_map[label] for label in all_labels[i]]

            final_labels = np.zeros(aligned_labels.shape[1], dtype=int)
            for idx in range(aligned_labels.shape[1]):
            
                labels_to_vote = aligned_labels[:, idx]
                counts = np.bincount(labels_to_vote, minlength=n_clusters)
                final_labels[idx] = np.argmax(counts)

            
            adata.obs['pred'] = final_labels
            pred=final_labels
        elif tool =='leiden_jc':
            adata.obsm['MGCN']=fea.data.cpu().numpy()
    
            best_res, resolutions, cluster_assignments = search_res_for_ensemble(
                adata, 
                n_clusters=args.n_clusters,
                use_rep='MGCN',
                method='leiden',
                num_extra=20
            )

  
            consensus_labels = consensus_clustering(cluster_assignments, n_clusters=10)


            adata.obs['consensus_clusters'] = consensus_labels.astype(str)
            pred=consensus_labels

        adata.obs['pred']=pred
        adata.obs['pred'] = pd.Categorical(adata.obs['pred'])  
        nmi, ari, ami, homogeneity, completeness, v_measure = eva(label, pred)
        nmi_result.append(nmi)
        ari_result.append(ari)
        ami_result.append(ami)
        homogeneity_result.append(homogeneity)
        completeness_result.append(completeness)
        v_measure_result.append(v_measure)
    print('methods{}'.format(tool))
    print_results(nmi_result, ari_result, ami_result, args,'test')
    return  nmi, ari, ami, homogeneity, completeness, v_measure
